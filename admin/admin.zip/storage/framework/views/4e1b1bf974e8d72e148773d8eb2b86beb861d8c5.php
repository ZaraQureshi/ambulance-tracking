<?php echo $__env->make('navigation-dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="row">
		<div class="col-md-2">
			<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		
		<div class="col-md-10">
			<div class="container-fluid">
			<?php if(session('msg')): ?>
			<div class="alert alert-success" role="alert">
					<?php echo e(session('msg')); ?>

				</div>
			<?php endif; ?>	
					
				
	
				<button class="btn btn-primary"><a href="driver_create" style="color:white;">create</a></button>
				<table class="table table-hover" style="text-align: center;">
				<thead>
					<tr>
					
					<th scope="col">Name</th>
					<th scope="col">Email</th>
					<th scope="col">Longitude</th>
					<th scope="col">Latitude</th>
					<th scope="col">Contact</th>
					<th scope="col">Status</th>
					<th scope="col">User</th>
					<th scope="col">Created_at</th>
					<th scope="col">Action</th>
					</tr>
				</thead>
				<?php $__currentLoopData = $driverArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					<tr>
					
					<td><?php echo e($driver->d_name); ?></td>
					<td><?php echo e($driver->d_email); ?></td>
					<td><?php echo e($driver->d_latitude); ?></td>
					<td><?php echo e($driver->d_longitude); ?></td>
					<td><?php echo e($driver->d_contact); ?></td>
					<td><?php echo e($driver->status); ?></td>
					<td><?php echo e($driver->user); ?></td>
					<td><?php echo e($driver->created_at); ?></td>
					<td><button class="btn btn-danger"><a href="driver_delete/<?php echo e($driver->id); ?>" style="color:white;">Delete</a></button> <button class="btn btn-primary"><a href="driver_edit/<?php echo e($driver->id); ?>" style="color:white;">Edit</a></button></td>
					
					</tr>
					
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
		</div>
	</div><?php /**PATH C:\Users\DELL\Documents\xampp\htdocs\project\php\admin\resources\views/driver_show.blade.php ENDPATH**/ ?>