<?php

//start session on web page
 

//config.php

//Include Google Client Library for PHP autoload file
require_once 'vendor/autoload.php';

//Make object of Google API Client for call Google API
$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('526187467134-329hhreqlliqkhe5jl7umk8o78sc6vu0.apps.googleusercontent.com');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('mZlIXxDpwQUR8QTaOmOy_vgp');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost:8080/project/php/user/g-callback.php');

$google_client->setApplicationName('atracks');
// to get the email and profile 
$google_client->addScope('email');

$google_client->addScope('profile');

?> 
