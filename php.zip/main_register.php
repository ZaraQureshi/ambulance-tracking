<head>
		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
		<link href="https://fonts.googleapis.com/css2?family=Lora:wght@500;600&family=Merriweather:wght@300;400&display=swap" rel="stylesheet">
	</head>
<div class="main_register">
    <h1>Register</h1>
    <a href="user/register.php" class="main_reg">Register as user</a><br><br>
    <p><a href="user/login.php">Login as user<a></p>
    <p>OR</p><br>
    <a href="driver/register_driver.php" class="main_reg">Register as driver</a><br><br>
    <p><a href="driver/login_driver.php">Login as driver</a></p>
  </div>