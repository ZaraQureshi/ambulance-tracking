<div class="sideMenu">
		<div class="sidebar">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a href="dashboard.php" class="nav-link">
						<i class="fa fa-tachometer" aria-hidden="true"></i>
						<span class="text">Dashboard</span>
					</a>
				</li>
				<li class="nav-item">
					<a href="profile.php" class="nav-link">
						<i class="fa fa-user-circle" aria-hidden="true"></i>
						<span class="text">Profile</span>
					</a>
				</li>
				
				<li class="nav-item">
					<a href="completed.php" class="nav-link">
						<i class="fa fa-check" aria-hidden="true"></i>
						<span class="text">Completed</span>
					</a>
				</li>
			</ul>
		</div>
	</div>