<?php echo $__env->make('navigation-dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="row">
		<div class="col-md-2">
			<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		
		<div class="col-md-10">
			<div class="container-fluid">
				<form method="POST" action="hospital_submit">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label >Name</label>
						<input type="text" class="form-control" id="name" name="name"value="" required>
					</div>
					<div class="form-group">
						<label >Lat</label>
						<input type="text" class="form-control" id="name" name="lat"value="" required>
					</div>
					<div class="form-group">
						<label >Long</label>
						<input type="text" class="form-control" id="name" name="long"value="" required>
					</div>
					<button type="submit" name="profileSubmit" class="btn btn-primary">Submit</button>
				</form>
			</div>
		</div>
	</div><?php /**PATH C:\Users\DELL\Documents\xampp\htdocs\project\php\admin\resources\views/hospital_create.blade.php ENDPATH**/ ?>